function AcidComputer( hObject, handles )
%ACIDCOMPUTER Summary of this function goes here
%   Detailed explanation goes here
% [GP,size,r] = computeOrbits(hObject, handles);

v = VideoWriter('tripppy.avi');
open(v)
fig = figure;
for n = 1:100
[GP] = changeConditions(hObject, handles, n); 
[x,y] = meshgrid(GP(:,2),GP(:,1));
% [X,Y] = pol2cart(GP(:,2),GP(:,1));
[X,Y] = pol2cart(x,y);
% contour(T,R,real(Z));hold on;
polarplot(X,Y);
F = getframe(fig);
writeVideo(v,F);
end


close(v);

% movie(v,1,60)
end

