% Parameters for solving the problem in the interval 0 < x < L
L = 10; % Interval Length
N = 100; % No of points
x = linspace(L,0,N); % Coordinate vector
dx = x(2) - x(1); % Coordinate step

% Parameters for making intial momentum space wavefunction phi(k)
ko = 2; % Peak momentum
a = 20; % Momentum width parameter
dk = 2*pi/L; % Momentum step
km=N*dk; % Momentum limit
k=linspace(0,+km,N); % Momentum vector


% Make psi(x,0) from Gaussian kspace wavefunction phi(k) using
% fast fourier transform :
phi = exp(-a*(k-ko).^2).*exp(-1i*6*k.^2); % unnormalized phi(k)
u = ifft(phi); % multiplies phi by expikx and integrates vs. x
u = u/sqrt(u'*u*dx); % normalize the psi(x,0)
WP = conj(u).*u;

% Potential U(x)
U = -(1-(2./x)); %% t component of metric


% Finite-difference representation of Laplacian and Hamiltonian
e = ones(N,1); Lap = spdiags([e -2*e e],[-1 0 1],N,N)/dx^2;
H = -(1/2)*Lap...
    + spdiags(U,0,N,N);


% Parameters for computing psi(x,T) at different times 0 < T < TF
NT = 200; % No. of time steps
TF = 29; T = linspace(0,TF,NT); % Time vector
dT = T(2)-T(1); % Time step
hbar = 1;


% Time displacement operator E=exp(-iHdT/hbar)
E = expm(-1i*full(H)*dT/hbar); % time displacement operator


%***************************************************************
% Simulate rho(x,T) and plot for each T
%***************************************************************

for t = 1:NT % time index for loop
% calculate probability density rho(x,T)
psi = E*psi; % calculate new psi from old psi
rho = conj(psi).*psi; % rho(x,T)
plot(x,rho,'k'); % plot rho(x,T) vs. x
axis([0 L 0 0.15]); % set x,y axis parameters for plotting
xlabel('x [m]', FontSize, 24);
ylabel('probability density [1/m]','FontSize', 24);
pause(0.05); % pause between each frame displayed
end